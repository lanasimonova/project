import tkinter as tk 
from tkinter import ttk
import sqlite3

class Main(tk.Frame):
    def _init_(self, root):
        super._init_(root)
        self.init_main()
        self.db = db

    def init_main(self):
        #Создаем панель инструментов
        toolbar = tk.Frame(bg='#d7d8e0', bd=2)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        self.add_img = tk.PhotoImage(file='./img/add.png')
        btn_open_dialog = tk.Button(toolbar, bg='#d7d8e0', bd=0,
        image = self.add_img, command=self.open_dialog)
        btn_open_dialog.pack(side=tk.LEFT)
        self.tree = ttk.Treeview(self, columns=('ID', 'name', 'tel', 'email'),
            height=45, show='headings')
        self.tree.column("ID", width=30, anchor=tk.CENTER)
        self.tree.column("name", width=300, anchor=tk.CENTER)
        self.tree.column("tel", width=150, anchor=tk.CENTER)
        self.tree.column("email", width=150, anchor=tk.CENTER)

        self.tree.heading("ID", text='ID')
        self.tree.heading("name", text='ФИО')
        self.tree.heading("tel", text='Телефон')
        self.tree.heading("email", text=' E-mail')

        self.tree.pack(side=tk.LEFT)


    

        lable_name = tk.Label(self, text='ФИО')
        lable_name.place(x=50, y=50)
        lable_select = tk.Label(self, text='Телефон')
        lable_select.place(x=50, y=80)
        lable_sum = tk.Label(self, text= 'E-mail')
        lable_sum.place(x=50, y=110)

        self.entry_name = ttk.Entry(self)
        self.entry_name.place(x=200, y=50)

        self.entry_email = ttk.Entry(self)
        self.entry_email.place(x=200, y=80)

        self.entry_tel = ttk.Entry(self)
        self.entry_tel.place(x=200, y=110)


        self.btn_cancel = ttk.Button(self, text='Закрыть',
                                     command=self.destroy)
        self.btn_cancel.place(x=300, y=170)

        self.btn_ok = ttk.Button(self, text='Добавить')
        self.btn_ok.place(x=220, y=170)

        self.btn_ok.bund('<Button-1>')

    def init_child(self):
        self.title('Добавить')
        self.geometry = ('400x220')
        self.resizable(False, False)
        self.grab_set()
        self.focus_set()

    def open_dialog(self):
        Child()
    def records(self, name, tel, email):
        self.db.insert_data(name, tel ,email)

class Child(tk.Toplevel):
    def _init_(self):
        super().__init__(root)
        self.init_child()

        
class DB:
    def _init_(self):
        self.conn = sqlite3.connect('db.db')
        self.c = self.conn.cursor()

        self.c.execute(
            '''CREATE TABLE IF NOT EXISTS db(
            id INTAGE PRIMARY KEY,
            name TEXT,
            tel TEXT,
            email TEXT
            )''')
        self.conn.commit()


    def insert_data(self, name, tel, email):
        self.c.execute('''INSERT INTO db(name, tel, email)
                       VALUES(?, ?, ?)''', (name, tel, email))
        self.conn.commit()
    

if __name__ == "_main_":
        root = tk.Tk()
        db = DB()
        app = Main(root)
        app.pack()
        #Заголовок окна
        root.title('Teлефонная книга')
        #Размер окна
        root.geometry('665x450')
        # Ограничения изменения размеров окна
        root.resizable(False, False)
        root.mainloop()